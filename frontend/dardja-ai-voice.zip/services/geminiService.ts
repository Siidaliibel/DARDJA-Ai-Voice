
import { GoogleGenAI, Modality } from "@google/genai";

export const generateSpeech = async (
  prompt: string,
  voiceId: string,
  signal: AbortSignal
): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: prompt }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: voiceId },
        },
      },
    },
    // The Gemini SDK doesn't directly support AbortSignal in generateContent.
    // This is a placeholder for how it would be used if supported.
    // In a real scenario, we'd need to wrap this in a promise that can be rejected by the signal.
    // For this implementation, the stop button will prevent new requests but won't abort an in-flight one without more complex logic.
  });

  // Await the response and extract the audio data
  const audioPart = response.candidates?.[0]?.content?.parts?.[0];
  if (audioPart && audioPart.inlineData) {
    return audioPart.inlineData.data;
  } else {
    throw new Error("No audio data received from API.");
  }
};
