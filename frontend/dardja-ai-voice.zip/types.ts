
export type Language = 'en' | 'fr' | 'ar';

export interface Voice {
  name: string;
  id: string;
}

export type Translations = {
  [key in Language]: {
    [key: string]: string;
  };
};
