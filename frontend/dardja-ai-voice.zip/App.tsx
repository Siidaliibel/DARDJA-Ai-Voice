
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { MAX_GENERATIONS, VOICES, DEFAULT_VOICE_STYLE_PROMPT, EXAMPLE_SCRIPT_TEXT, TRANSLATIONS } from './constants';
import type { Language, Voice } from './types';
import { generateSpeech } from './services/geminiService';
import { pcmToWavBlob } from './utils/audioUtils';
import { Logo } from './Logo';

const Header: React.FC<{ language: Language; setLanguage: (lang: Language) => void; siteTitle: string; }> = ({ language, setLanguage, siteTitle }) => (
  <header className="py-4 px-4 md:px-8 w-full relative mb-4">
    <div className="opacity-0 animate-fade-in flex flex-col items-center">
      <Logo />
      <h1 className="text-3xl md:text-4xl font-merriweather text-center mt-4 tracking-wider animated-gradient-text">
        {siteTitle}
      </h1>
    </div>
    <div className="absolute top-6 right-4 md:right-8 flex gap-2 text-sm">
      {(['en', 'fr', 'ar'] as Language[]).map(lang => (
        <button
          key={lang}
          onClick={() => setLanguage(lang)}
          className={`px-2 py-1 rounded-md transition-colors ${language === lang ? 'bg-[#1A73E8] text-white' : 'bg-gray-800 bg-opacity-70 hover:bg-gray-700'}`}
        >
          {lang.toUpperCase()}
        </button>
      ))}
    </div>
  </header>
);

const AudioPlayer: React.FC<{ audioUrl: string; trans: Record<string, string>; }> = ({ audioUrl, trans }) => {
    const audioRef = useRef<HTMLAudioElement>(null);
    const [playbackRate, setPlaybackRate] = useState(1);

    useEffect(() => {
        if (audioRef.current) {
            audioRef.current.playbackRate = playbackRate;
        }
    }, [playbackRate]);
    
    useEffect(() => {
        // Autoplay when new audio is generated
        if (audioRef.current) {
            audioRef.current.play();
        }
    }, [audioUrl]);


    return (
        <div className="mt-6 p-4 bg-gray-800 rounded-lg shadow-lg w-full">
            <audio ref={audioRef} key={audioUrl} controls src={audioUrl} className="w-full">
                Your browser does not support the audio element.
            </audio>
            <div className="flex items-center justify-between mt-4">
                <div className="flex items-center gap-2">
                    <label htmlFor="speed-control" className="text-sm">{trans.speedControl}:</label>
                    <select
                        id="speed-control"
                        value={playbackRate}
                        onChange={(e) => setPlaybackRate(Number(e.target.value))}
                        className="bg-gray-700 border border-gray-600 rounded-md px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-[#1A73E8]"
                    >
                        {[0.75, 1, 1.25, 1.5, 1.75, 2].map(speed => (
                            <option key={speed} value={speed}>{speed}x</option>
                        ))}
                    </select>
                </div>
                <a
                    href={audioUrl}
                    download="dardja_ai_voice.wav"
                    className="bg-[#1A73E8] hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg transition-colors shadow-md text-sm"
                >
                    {trans.downloadWav}
                </a>
            </div>
        </div>
    );
};

export default function App() {
  const [language, setLanguage] = useState<Language>('en');
  const [voiceStylePrompt, setVoiceStylePrompt] = useState(DEFAULT_VOICE_STYLE_PROMPT);
  const [scriptText, setScriptText] = useState('');
  const [selectedVoice, setSelectedVoice] = useState<string>(VOICES[0].id);
  const [generationCount, setGenerationCount] = useState(0);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationTime, setGenerationTime] = useState(0);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const timerIntervalRef = useRef<number | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  const trans = TRANSLATIONS[language];
  const isLimitReached = generationCount >= MAX_GENERATIONS;

  useEffect(() => {
    const storedCount = localStorage.getItem('generationCount');
    if (storedCount) {
      setGenerationCount(parseInt(storedCount, 10));
    }
    const userLang = navigator.language.split('-')[0] as Language;
    if (['en', 'fr', 'ar'].includes(userLang)) {
      setLanguage(userLang);
    }
  }, []);

  const startTimer = useCallback(() => {
    setGenerationTime(0);
    timerIntervalRef.current = window.setInterval(() => {
      setGenerationTime(prevTime => prevTime + 1);
    }, 1000);
  }, []);

  const stopTimer = useCallback(() => {
    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
  }, []);

  const handleGenerate = async () => {
    if (isLimitReached || isGenerating) return;

    setIsGenerating(true);
    setError(null);
    startTimer();
    
    abortControllerRef.current = new AbortController(); 
    const currentAbortController = abortControllerRef.current;


    const fullPrompt = `${voiceStylePrompt} ${scriptText}`;

    try {
      const base64Audio = await generateSpeech(fullPrompt, selectedVoice, currentAbortController.signal);
      
      if(currentAbortController.signal.aborted) {
        console.log("Generation was cancelled after API call returned.");
        return;
      }
      
      const wavBlob = pcmToWavBlob(base64Audio);
      const newAudioUrl = URL.createObjectURL(wavBlob);
      
      // Revoke the old URL before setting the new one to prevent memory leaks
      if (audioUrl) {
          URL.revokeObjectURL(audioUrl);
      }
      setAudioUrl(newAudioUrl);
      
      const newCount = generationCount + 1;
      setGenerationCount(newCount);
      localStorage.setItem('generationCount', newCount.toString());

    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.error('Generation failed:', err);
        setError(trans.generationError);
      }
    } finally {
      setIsGenerating(false);
      stopTimer();
    }
  };

  const handleStop = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setIsGenerating(false);
    stopTimer();
    setGenerationTime(0);
  };

  const handleTryExample = () => {
    setVoiceStylePrompt(DEFAULT_VOICE_STYLE_PROMPT);
    setScriptText(EXAMPLE_SCRIPT_TEXT);
  };

  const formatTime = (timeInSeconds: number) => {
    const minutes = Math.floor(timeInSeconds / 60).toString().padStart(2, '0');
    const seconds = (timeInSeconds % 60).toString().padStart(2, '0');
    return `${minutes}:${seconds}`;
  };

  return (
    <div dir={language === 'ar' ? 'rtl' : 'ltr'} className={`min-h-screen flex flex-col items-center p-4 md:p-8 ${language === 'ar' ? 'font-cairo' : 'font-sans'}`}>
      <Header language={language} setLanguage={setLanguage} siteTitle={trans.siteTitle} />

      <main className="w-full max-w-3xl flex-grow flex flex-col items-center">
        <div className="w-full bg-gray-900 bg-opacity-50 p-6 rounded-2xl shadow-2xl border border-gray-700 space-y-6">
          
          {/* Input Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="voice-style-prompt" className="block mb-2 text-sm font-medium text-gray-300">{trans.voiceStylePromptLabel}</label>
              <textarea
                id="voice-style-prompt"
                rows={8}
                value={voiceStylePrompt}
                onChange={(e) => setVoiceStylePrompt(e.target.value)}
                className="w-full bg-gray-800 border border-gray-600 rounded-lg p-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#1A73E8] transition-all"
              ></textarea>
            </div>
            <div>
              <label htmlFor="script-text" className="block mb-2 text-sm font-medium text-gray-300">{trans.scriptTextLabel}</label>
              <textarea
                id="script-text"
                rows={8}
                value={scriptText}
                onChange={(e) => setScriptText(e.target.value)}
                placeholder={language === 'ar' ? 'اكتب النص هنا...' : 'Enter your script here...'}
                className="w-full bg-gray-800 border border-gray-600 rounded-lg p-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#1A73E8] transition-all"
              ></textarea>
            </div>
          </div>
          <div className="flex justify-end">
             <button onClick={handleTryExample} className="text-sm text-[#1A73E8] hover:underline">
               {trans.tryExample}
             </button>
          </div>

          {/* Controls Section */}
          <div className="flex flex-col sm:flex-row items-center gap-4">
            <div className="w-full sm:w-auto">
              <label htmlFor="voice-select" className="sr-only">{trans.selectVoice}</label>
              <select
                id="voice-select"
                value={selectedVoice}
                onChange={(e) => setSelectedVoice(e.target.value)}
                className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#1A73E8] h-10" // Compact height
              >
                {VOICES.map((voice: Voice) => (
                  <option key={voice.id} value={voice.id}>{voice.name}</option>
                ))}
              </select>
            </div>
            
            <div className="flex-grow flex items-center gap-2 w-full sm:w-auto">
                {isGenerating && (
                    <div className="text-sm font-mono text-gray-400 w-12">{formatTime(generationTime)}</div>
                )}
                {isGenerating ? (
                    <button onClick={handleStop} className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg transition-colors shadow-md flex-grow">
                        {trans.stopGeneration}
                    </button>
                ) : (
                    <button
                        onClick={handleGenerate}
                        disabled={isLimitReached || !scriptText}
                        className="w-full bg-[#1A73E8] hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg transition-colors shadow-md disabled:bg-gray-600 disabled:cursor-not-allowed flex-grow"
                    >
                        {isGenerating ? trans.generating : trans.generateVoice}
                    </button>
                )}
            </div>
          </div>

          {/* Status Messages */}
          {isLimitReached && <p className="text-center text-yellow-400 text-sm mt-2">{trans.limitReached}</p>}
          {error && <p className="text-center text-red-400 text-sm mt-2">{error}</p>}
          <p className="text-center text-xs text-gray-500 mt-2">{generationCount} / {MAX_GENERATIONS} generations used.</p>

          {/* Audio Player */}
          {audioUrl && <AudioPlayer audioUrl={audioUrl} trans={trans}/>}

        </div>
      </main>

      <footer className="w-full text-center text-gray-500 text-xs py-4 mt-8">
        {trans.footerText}
      </footer>
    </div>
  );
}